import { reducerTodo, initialState, State } from './reducer';
import * as Actions from './actions';

describe('reducerTodo', () => {
  it('should handle "ADDTODO" action', () => {
    const todo = { id: 1, name: 'Test Todo', completed: false };
    const action = Actions.ADDTODO({ todo });

    const newState = reducerTodo(initialState, action);

    expect(newState.todos[0]).toEqual(todo);
  });
});
